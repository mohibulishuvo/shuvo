# Portfolio website

Tech used:
- Svelte
- Typescript
- TailwindCSS
